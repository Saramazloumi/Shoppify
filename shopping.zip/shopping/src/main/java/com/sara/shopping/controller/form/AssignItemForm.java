package com.sara.shopping.controller.form;

import lombok.Data;

@Data
public class AssignItemForm {
	
	private String email;
	private String code;

}
