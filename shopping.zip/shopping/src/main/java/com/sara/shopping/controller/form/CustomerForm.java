package com.sara.shopping.controller.form;

import lombok.Data;

@Data
public class CustomerForm {
	
	private String email;	
	private String password;	
	private String name;

}
