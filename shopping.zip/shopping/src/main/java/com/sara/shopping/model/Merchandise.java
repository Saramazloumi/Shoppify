package com.sara.shopping.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.validation.constraints.NotNull;

import com.fasterxml.jackson.annotation.JsonIgnore;

import lombok.Data;

@Entity
@Data
public class Merchandise {
	
	@Id
	@GeneratedValue
	@JsonIgnore
	private long id;
	@Column(unique = true, nullable = false)
	private String code;
	@NotNull
	private String name;
	@NotNull
	private double price;
	private String description;
	

}
