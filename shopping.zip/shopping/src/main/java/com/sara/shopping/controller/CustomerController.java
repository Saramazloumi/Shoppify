package com.sara.shopping.controller;

import java.util.Collection;
import java.util.HashSet;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import com.sara.shopping.controller.form.CustomerForm;
import com.sara.shopping.model.Customer;
import com.sara.shopping.model.Merchandise;
import com.sara.shopping.repo.CustomerRepo;

@RestController
public class CustomerController {
	
	private CustomerRepo cRepo;

	@Autowired
	public CustomerController(CustomerRepo cRepo) {
		this.cRepo = cRepo;
	}
	
	@RequestMapping(value = "/customers", method = RequestMethod.GET)
	public Collection<Customer> findAll(){
		return cRepo.findAll();
	}
	
	@RequestMapping(value = "/customer/create", method = RequestMethod.POST)
	public CustomerForm createCustomer(@RequestBody CustomerForm customerForm) {
		Customer customer = new Customer();
		customer.setName(customerForm.getName());
		customer.setEmail(customerForm.getEmail());
		customer.setPassword(customerForm.getPassword());
		customer.setCart(new HashSet<>());
		this.cRepo.save(customer);
		return customerForm;
	}
	
	@RequestMapping(value = "/customer/{email}/items", method = RequestMethod.GET)
	public Collection<Merchandise> getItemsForCustomer(@PathVariable String email){
		try {
			return this.cRepo.findCustomerByEmail(email).orElseThrow().getCart();
		}catch(Exception e) {
			e.printStackTrace();
			return new HashSet<Merchandise>();
		}		
	}
	
	

}
