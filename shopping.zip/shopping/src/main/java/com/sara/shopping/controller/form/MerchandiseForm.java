package com.sara.shopping.controller.form;

import lombok.Data;

@Data
public class MerchandiseForm {
	
	private String code;
	private String name;
	private double price;
	private String description;

}
