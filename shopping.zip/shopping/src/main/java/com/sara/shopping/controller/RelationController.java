package com.sara.shopping.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import com.sara.shopping.controller.form.AssignItemForm;
import com.sara.shopping.model.Customer;
import com.sara.shopping.model.Merchandise;
import com.sara.shopping.repo.CustomerRepo;
import com.sara.shopping.repo.MerchandiseRepo;

@RestController
public class RelationController {
	
	private CustomerRepo cRepo;
	private MerchandiseRepo mRepo;
	
	@Autowired
	public RelationController(CustomerRepo cRepo, MerchandiseRepo mRepo) {
		this.cRepo = cRepo;
		this.mRepo = mRepo;
	}
	
	private String assignItemsToCustomer(String email, String code) {
		
		try {
			Customer customer = this.cRepo.findCustomerByEmail(email).orElseThrow();
			Merchandise merchandise = this.mRepo.findItemByCode(code).orElseThrow();
			customer.getCart().add(merchandise);
			this.cRepo.save(customer);
			this.mRepo.save(merchandise);
			return "Success!";			
		}catch (Exception e) {
			e.printStackTrace();
			return "Unable to find customer or items!";
		}
	}
	
	@RequestMapping(value = "/assign/items", method = RequestMethod.POST , consumes = "application/json")
	public AssignItemForm assignItemsToCustomers(@RequestBody AssignItemForm assignItemForm) {
		if(assignItemsToCustomer(assignItemForm.getEmail(), assignItemForm.getCode()) == "Success!") {
			return assignItemForm;
		} else {
			return null;
		}
	}
	
	@RequestMapping(value = "/assign/items", method = RequestMethod.POST , consumes = "multipart/form-data")
	public String assignItemsToCustomers_Param(@RequestParam String email, @RequestParam String code) {
		return assignItemsToCustomer(email, code);
	}

}
