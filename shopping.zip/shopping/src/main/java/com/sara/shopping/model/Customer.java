package com.sara.shopping.model;

import java.util.Collection;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.validation.constraints.NotNull;
import com.fasterxml.jackson.annotation.JsonIgnore;
import lombok.Data;
import lombok.EqualsAndHashCode;

@Entity
@Data
@EqualsAndHashCode (exclude = "cart")
public class Customer {
	
	@Id
	@GeneratedValue
	@JsonIgnore
	private long id;	
	@Column(unique = true, nullable = false)
	private String email;	
	@NotNull
	private String password;	
	@NotNull
	private String name;
	
	@OneToMany
	@JsonIgnore
	Collection<Merchandise> cart;

}
