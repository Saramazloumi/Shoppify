package com.sara.shopping.controller;

import java.util.Collection;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import com.sara.shopping.controller.form.MerchandiseForm;
import com.sara.shopping.model.Merchandise;
import com.sara.shopping.repo.MerchandiseRepo;

@RestController
public class MerchandiseController {
	
	private MerchandiseRepo mRepo;

	@Autowired
	public MerchandiseController(MerchandiseRepo mRepo) {
		this.mRepo = mRepo;
	}
	
	@RequestMapping(value = "/items", method = RequestMethod.GET)
	public Collection<Merchandise> findAll(){
		return this.mRepo.findAll();
	}
	
	@RequestMapping(value = "/item/create", method = RequestMethod.POST)
	public MerchandiseForm createItem(@RequestBody MerchandiseForm merchandiseForm) {
		Merchandise merchandise = new Merchandise();
		merchandise.setCode(merchandiseForm.getCode());
		merchandise.setName(merchandiseForm.getName());
		merchandise.setPrice(merchandiseForm.getPrice());
		merchandise.setDescription(merchandiseForm.getDescription());
		this.mRepo.save(merchandise);
		return merchandiseForm;
	}
	
	

}
